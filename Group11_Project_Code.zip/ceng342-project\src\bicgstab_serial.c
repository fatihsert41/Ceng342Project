/**
 * bicgstab_serial.c - Serial Mixed Precision BiCGSTAB.
 *
 * Reference implementation: easy to read, used for correctness checks
 * and as a baseline for OpenMP/MPI speedup measurements.
 *
 * Mixed precision: SpMV uses A->vals_f32 (see csr_spmv_mixed).
 */
#include "bicgstab.h"
#include "vector_ops.h"
#include "csr_matrix.h"
#include "timer.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

BiCGSTABResult bicgstab_serial(const CSRMatrix *A,
                               const double *b,
                               double *x,
                               const BiCGSTABParams *params) {
    int n = A->nrows;
    BiCGSTABResult res = {0, 0.0, 0, 0.0};

    /* Workspace */
    double *r     = (double *)malloc((size_t)n * sizeof(double));
    double *r_hat = (double *)malloc((size_t)n * sizeof(double));
    double *p     = (double *)malloc((size_t)n * sizeof(double));
    double *v     = (double *)malloc((size_t)n * sizeof(double));
    double *s     = (double *)malloc((size_t)n * sizeof(double));
    double *t     = (double *)malloc((size_t)n * sizeof(double));

    double t_start = wtime();

    /* ----- 1) Baslangic: r0 = b - A*x0 ----- */
    csr_spmv_mixed(A, x, v);            /* v = A*x0 (gecici buffer olarak v kullaniyoruz) */
    vec_sub_scaled(r, b, 1.0, v, n);    /* r = b - 1.0 * v */

    /* r_hat = r0,  p = r0 */
    vec_copy(r_hat, r, n);
    vec_copy(p,     r, n);

    double bnorm = vec_norm2(b, n);
    if (bnorm == 0.0) bnorm = 1.0;      /* b == 0 ise rel. residual'i bozma */

    double rho_old = vec_dot(r_hat, r, n);
    double alpha = 1.0, omega = 1.0, beta = 0.0;
    double rnorm = vec_norm2(r, n);

    int k;
    for (k = 0; k < params->max_iter; k++) {
        /* a) Yakinsama kontrolu */
        if (rnorm / bnorm < params->tol) {
            res.converged = 1;
            break;
        }

        /* b) v = A * p */
        csr_spmv_mixed(A, p, v);

        /* c) alpha = rho_old / <r_hat, v> */
        double rhv = vec_dot(r_hat, v, n);
        if (rhv == 0.0) {
            fprintf(stderr, "  [serial] breakdown <r_hat,v>=0\n");
            break;
        }
        alpha = rho_old / rhv;

        /* d) s = r - alpha * v */
        vec_sub_scaled(s, r, alpha, v, n);

        /* e) Erken cikis: ||s|| yeterince kucukse x += alpha*p ile bitir */
        double snorm = vec_norm2(s, n);
        if (snorm / bnorm < params->tol) {
            vec_axpy(x, alpha, p, n);
            rnorm = snorm;
            res.converged = 1;
            k++;
            break;
        }

        /* f) t = A * s */
        csr_spmv_mixed(A, s, t);

        /* g) omega = <t,s> / <t,t> */
        double ts = vec_dot(t, s, n);
        double tt = vec_dot(t, t, n);
        if (tt == 0.0) {
            fprintf(stderr, "  [serial] breakdown <t,t>=0\n");
            break;
        }
        omega = ts / tt;

        /* h) x = x + alpha*p + omega*s */
        vec_axpy(x, alpha, p, n);
        vec_axpy(x, omega, s, n);

        /* i) r = s - omega*t */
        vec_sub_scaled(r, s, omega, t, n);

        rnorm = vec_norm2(r, n);
        if (params->verbose && (k % 50 == 0)) {
            printf("  [serial] iter %4d  |r|/|b| = %.3e\n", k, rnorm / bnorm);
        }

        /* j) rho_new ve beta */
        double rho_new = vec_dot(r_hat, r, n);
        if (omega == 0.0 || rho_old == 0.0) {
            fprintf(stderr, "  [serial] breakdown omega/rho=0\n");
            break;
        }
        beta = (rho_new / rho_old) * (alpha / omega);
        rho_old = rho_new;

        /* k) p = r + beta * (p - omega * v)  (fused update) */
        for (int i = 0; i < n; i++) {
            p[i] = r[i] + beta * (p[i] - omega * v[i]);
        }
    }

    res.iters         = k;
    res.final_resnorm = rnorm / bnorm;
    res.elapsed_sec   = wtime() - t_start;

    free(r); free(r_hat); free(p); free(v); free(s); free(t);
    return res;
}
