/**
 * vector_ops.h - Basic BLAS-1 like vector operations.
 *
 * Provides serial and OpenMP variants. The functions operate on a single
 * (local) chunk of a vector. For MPI, global reductions must be done by
 * the caller (see bicgstab_mpi.c).
 */
#ifndef VECTOR_OPS_H
#define VECTOR_OPS_H

#include <stddef.h>

/* ---------- Serial ---------- */

/* Dot product:  return sum_i a[i]*b[i] */
double vec_dot(const double *a, const double *b, int n);

/* y[i] += alpha * x[i] */
void vec_axpy(double *y, double alpha, const double *x, int n);

/* y[i] = beta*y[i] + alpha*x[i] */
void vec_axpby(double *y, double alpha, const double *x, double beta, int n);

/* z[i] = a[i] - alpha*b[i] */
void vec_sub_scaled(double *z, const double *a, double alpha,
                    const double *b, int n);

/* y[i] = x[i] (copy) */
void vec_copy(double *y, const double *x, int n);

/* y[i] = 0 */
void vec_zero(double *y, int n);

/* L2 norm */
double vec_norm2(const double *x, int n);

/* ---------- OpenMP variants ---------- */

double vec_dot_omp(const double *a, const double *b, int n);
void   vec_axpy_omp(double *y, double alpha, const double *x, int n);
void   vec_axpby_omp(double *y, double alpha, const double *x,
                     double beta, int n);
void   vec_sub_scaled_omp(double *z, const double *a, double alpha,
                          const double *b, int n);
double vec_norm2_omp(const double *x, int n);

#endif /* VECTOR_OPS_H */
