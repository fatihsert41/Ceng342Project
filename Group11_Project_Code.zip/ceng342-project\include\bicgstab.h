/**
 * bicgstab.h - Mixed Precision BiCGSTAB solver interfaces.
 *
 * Three backends are provided:
 *   1. Serial            (bicgstab_serial.c)
 *   2. OpenMP            (bicgstab_omp.c)
 *   3. MPI + OpenMP      (bicgstab_mpi.c)  -- uses MPI_Iallreduce
 *
 * Mixed precision strategy:
 *   - Matrix A is stored in BOTH float32 and float64 (see csr_matrix.h).
 *   - SpMV reads A in float32 (saves bandwidth) but accumulates in double.
 *   - All BiCGSTAB working vectors and reductions are in double.
 *
 * Returns the number of iterations performed.
 * Sets *out_resnorm to the final relative residual norm.
 */
#ifndef BICGSTAB_H
#define BICGSTAB_H

#include "csr_matrix.h"

/* Common solver parameters */
typedef struct {
    int    max_iter;
    double tol;       /* relative residual tolerance |r|/|b| */
    int    verbose;   /* 0 = silent, 1 = print every 50 iters */
} BiCGSTABParams;

/* Common solver result */
typedef struct {
    int    iters;
    double final_resnorm;
    int    converged;
    double elapsed_sec;
} BiCGSTABResult;

/* ---------- Serial backend ---------- */
BiCGSTABResult bicgstab_serial(const CSRMatrix *A,
                               const double *b,
                               double *x,
                               const BiCGSTABParams *params);

/* ---------- OpenMP backend ---------- */
BiCGSTABResult bicgstab_omp(const CSRMatrix *A,
                            const double *b,
                            double *x,
                            const BiCGSTABParams *params);

/* ---------- MPI + OpenMP backend ----------
 *
 * A is the LOCAL CSR portion held by this rank (rows row_start .. row_start+local_n-1).
 * b_local, x_local are size local_n.
 *
 * Uses MPI_Iallreduce for all global reductions to overlap with computation.
 *
 * NOTE: caller must have already called MPI_Init / MPI_Init_thread.
 */
#ifdef USE_MPI
#include <mpi.h>
BiCGSTABResult bicgstab_mpi(const CSRMatrix *A_local,
                            const double *b_local,
                            double *x_local,
                            int global_n,
                            int row_start,
                            const BiCGSTABParams *params,
                            MPI_Comm comm);
#endif

#endif /* BICGSTAB_H */
