/**
 * bicgstab_mpi.c - MPI + OpenMP Mixed Precision BiCGSTAB.
 *
 * Distributed memory parallelism strategy
 * ---------------------------------------
 *  - The matrix is row-distributed: rank p owns rows [row_start_p, ...]
 *  - Each rank holds its local CSR slice; column indices are GLOBAL.
 *  - Before every SpMV we MPI_Allgatherv the input vector so every rank
 *    has the full vector and can multiply its local rows independently.
 *  - All inner products are computed locally (with OpenMP reduction)
 *    then combined with MPI_Iallreduce (non-blocking) so the reduction
 *    overlaps with subsequent local work.
 *  - Multiple scalars that can be reduced together are PACKED into a
 *    single MPI_Iallreduce call (e.g. <t,s> and <t,t>) to halve latency.
 *
 * Local kernels reuse the OpenMP vector ops from vector_ops_omp.c
 * and the OpenMP SpMV from csr_matrix.c (csr_spmv_mixed_omp).
 */
#include "bicgstab.h"
#include "vector_ops.h"
#include "csr_matrix.h"
#include "timer.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifdef USE_MPI
#include <mpi.h>
#endif

#ifdef _OPENMP
#include <omp.h>
#endif

#ifdef USE_MPI

/* Helper: launch a non-blocking allreduce of a single double */
static inline void iallreduce_scalar(double local, double *global,
                                     MPI_Request *req, MPI_Comm comm) {
    *global = local;
    MPI_Iallreduce(MPI_IN_PLACE, global, 1, MPI_DOUBLE,
                   MPI_SUM, comm, req);
}

/* Helper: launch a non-blocking allreduce of TWO doubles packed together */
static inline void iallreduce_pair(double l1, double l2,
                                   double *g_pair /* size 2 */,
                                   MPI_Request *req, MPI_Comm comm) {
    g_pair[0] = l1;
    g_pair[1] = l2;
    MPI_Iallreduce(MPI_IN_PLACE, g_pair, 2, MPI_DOUBLE,
                   MPI_SUM, comm, req);
}

BiCGSTABResult bicgstab_mpi(const CSRMatrix *A_local,
                            const double *b_local,
                            double *x_local,
                            int global_n,
                            int row_start,
                            const BiCGSTABParams *params,
                            MPI_Comm comm) {
    BiCGSTABResult res = {0, 0.0, 0, 0.0};

    int rank, nprocs;
    MPI_Comm_rank(comm, &rank);
    MPI_Comm_size(comm, &nprocs);

    int local_n = A_local->nrows;

    /* ----- compute Allgatherv layout (recvcounts/displs) once ----- */
    int *recvcounts = (int *)malloc((size_t)nprocs * sizeof(int));
    int *displs     = (int *)malloc((size_t)nprocs * sizeof(int));
    {
        int my_lo[2] = {row_start, local_n};
        int *all_lo  = (int *)malloc((size_t)nprocs * 2 * sizeof(int));
        MPI_Allgather(my_lo, 2, MPI_INT, all_lo, 2, MPI_INT, comm);
        for (int p = 0; p < nprocs; p++) {
            displs[p]     = all_lo[2 * p];
            recvcounts[p] = all_lo[2 * p + 1];
        }
        free(all_lo);
    }

    /* ----- allocate workspace ----- */
    double *r      = (double *)malloc((size_t)local_n * sizeof(double));
    double *r_hat  = (double *)malloc((size_t)local_n * sizeof(double));
    double *p_loc  = (double *)malloc((size_t)local_n * sizeof(double));
    double *v      = (double *)malloc((size_t)local_n * sizeof(double));
    double *s      = (double *)malloc((size_t)local_n * sizeof(double));
    double *t      = (double *)malloc((size_t)local_n * sizeof(double));

    /* Full (gathered) vectors required by SpMV (column indices are global) */
    double *x_full = (double *)malloc((size_t)global_n * sizeof(double));
    double *p_full = (double *)malloc((size_t)global_n * sizeof(double));
    double *s_full = (double *)malloc((size_t)global_n * sizeof(double));

    MPI_Barrier(comm);
    double t_start = wtime();

    /* r0 = b - A*x0 */
    MPI_Allgatherv(x_local, local_n, MPI_DOUBLE,
                   x_full, recvcounts, displs, MPI_DOUBLE, comm);
    csr_spmv_mixed_omp(A_local, x_full, v);
    vec_sub_scaled_omp(r, b_local, 1.0, v, local_n);

#ifdef _OPENMP
    #pragma omp parallel for schedule(static)
#endif
    for (int i = 0; i < local_n; i++) {
        r_hat[i] = r[i];
        p_loc[i] = r[i];
    }

    /* |b| (global) */
    double bnorm;
    {
        double local_bb = vec_dot_omp(b_local, b_local, local_n);
        MPI_Allreduce(&local_bb, &bnorm, 1, MPI_DOUBLE, MPI_SUM, comm);
        bnorm = sqrt(bnorm);
        if (bnorm == 0.0) bnorm = 1.0;
    }

    /* rho_0 = <r_hat, r> (global) */
    double rho_old;
    {
        double loc = vec_dot_omp(r_hat, r, local_n);
        MPI_Allreduce(&loc, &rho_old, 1, MPI_DOUBLE, MPI_SUM, comm);
    }

    /* |r0| (global) */
    double rnorm;
    {
        double loc = vec_dot_omp(r, r, local_n);
        MPI_Allreduce(&loc, &rnorm, 1, MPI_DOUBLE, MPI_SUM, comm);
        rnorm = sqrt(rnorm);
    }

    double alpha = 1.0, omega = 1.0, beta = 0.0;

    int k;
    for (k = 0; k < params->max_iter; k++) {
        if (rnorm / bnorm < params->tol) {
            res.converged = 1;
            break;
        }

        /* ---- v = A * p ---- */
        MPI_Allgatherv(p_loc, local_n, MPI_DOUBLE,
                       p_full, recvcounts, displs, MPI_DOUBLE, comm);
        csr_spmv_mixed_omp(A_local, p_full, v);

        /* alpha = rho_old / <r_hat, v>  (single non-blocking reduction) */
        double rhv_loc = vec_dot_omp(r_hat, v, local_n);
        double rhv_glb;
        MPI_Request req_rhv;
        iallreduce_scalar(rhv_loc, &rhv_glb, &req_rhv, comm);

        /* No useful work to overlap before alpha is known => wait */
        MPI_Wait(&req_rhv, MPI_STATUS_IGNORE);
        if (rhv_glb == 0.0) {
            if (rank == 0) fprintf(stderr, "  [mpi] breakdown <r_hat,v>=0\n");
            break;
        }
        alpha = rho_old / rhv_glb;

        /* ---- s = r - alpha * v ---- */
        vec_sub_scaled_omp(s, r, alpha, v, local_n);

        /* Start non-blocking reduction for |s|^2 ... */
        double snorm2_loc = vec_dot_omp(s, s, local_n);
        double snorm2_glb;
        MPI_Request req_snorm;
        iallreduce_scalar(snorm2_loc, &snorm2_glb, &req_snorm, comm);

        /* ... while it travels, prepare next SpMV's allgather (overlap!) */
        MPI_Allgatherv(s, local_n, MPI_DOUBLE,
                       s_full, recvcounts, displs, MPI_DOUBLE, comm);

        MPI_Wait(&req_snorm, MPI_STATUS_IGNORE);
        double snorm = sqrt(snorm2_glb);

        if (snorm / bnorm < params->tol) {
            /* x += alpha * p ;  done */
            vec_axpy_omp(x_local, alpha, p_loc, local_n);
            rnorm = snorm;
            res.converged = 1;
            k++;
            break;
        }

        /* ---- t = A * s ---- */
        csr_spmv_mixed_omp(A_local, s_full, t);

        /* omega = <t,s> / <t,t> -- pack two reductions into one Iallreduce */
        double ts_loc = vec_dot_omp(t, s, local_n);
        double tt_loc = vec_dot_omp(t, t, local_n);
        double pair[2];
        MPI_Request req_om;
        iallreduce_pair(ts_loc, tt_loc, pair, &req_om, comm);
        MPI_Wait(&req_om, MPI_STATUS_IGNORE);
        if (pair[1] == 0.0) {
            if (rank == 0) fprintf(stderr, "  [mpi] breakdown <t,t>=0\n");
            break;
        }
        omega = pair[0] / pair[1];

        /* x = x + alpha*p + omega*s  (fused, OpenMP) */
#ifdef _OPENMP
        #pragma omp parallel for schedule(static)
#endif
        for (int i = 0; i < local_n; i++) {
            x_local[i] += alpha * p_loc[i] + omega * s[i];
        }

        /* r = s - omega * t */
        vec_sub_scaled_omp(r, s, omega, t, local_n);

        /* Non-blocking reduction for |r|^2 AND <r_hat,r> together (3 doubles)
         *    pair_long[0] = |r|^2
         *    pair_long[1] = <r_hat, r>  (=rho_new)
         */
        double rr_loc       = vec_dot_omp(r, r, local_n);
        double rho_new_loc  = vec_dot_omp(r_hat, r, local_n);
        double red[2] = { rr_loc, rho_new_loc };
        MPI_Request req_red;
        MPI_Iallreduce(MPI_IN_PLACE, red, 2, MPI_DOUBLE, MPI_SUM, comm, &req_red);
        MPI_Wait(&req_red, MPI_STATUS_IGNORE);

        rnorm = sqrt(red[0]);
        double rho_new = red[1];

        if (params->verbose && rank == 0 && (k % 50 == 0)) {
            printf("  [mpi] iter %4d  |r|/|b| = %.3e\n", k, rnorm / bnorm);
        }

        if (omega == 0.0 || rho_old == 0.0) {
            if (rank == 0) fprintf(stderr, "  [mpi] breakdown omega/rho=0\n");
            break;
        }
        beta = (rho_new / rho_old) * (alpha / omega);
        rho_old = rho_new;

        /* p = r + beta * (p - omega * v) */
#ifdef _OPENMP
        #pragma omp parallel for schedule(static)
#endif
        for (int i = 0; i < local_n; i++) {
            p_loc[i] = r[i] + beta * (p_loc[i] - omega * v[i]);
        }
    }

    res.iters         = k;
    res.final_resnorm = rnorm / bnorm;
    res.elapsed_sec   = wtime() - t_start;

    free(r); free(r_hat); free(p_loc); free(v); free(s); free(t);
    free(x_full); free(p_full); free(s_full);
    free(recvcounts); free(displs);

    return res;
}

#endif /* USE_MPI */
