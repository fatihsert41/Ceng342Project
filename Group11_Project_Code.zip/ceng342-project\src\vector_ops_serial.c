/**
 * vector_ops_serial.c - Serial BLAS-1 like vector kernels.
 */
#include "vector_ops.h"
#include <math.h>
#include <string.h>

double vec_dot(const double *a, const double *b, int n) {
    double s = 0.0;
    for (int i = 0; i < n; i++) s += a[i] * b[i];
    return s;
}

void vec_axpy(double *y, double alpha, const double *x, int n) {
    for (int i = 0; i < n; i++) y[i] += alpha * x[i];
}

void vec_axpby(double *y, double alpha, const double *x, double beta, int n) {
    for (int i = 0; i < n; i++) y[i] = beta * y[i] + alpha * x[i];
}

void vec_sub_scaled(double *z, const double *a, double alpha,
                    const double *b, int n) {
    for (int i = 0; i < n; i++) z[i] = a[i] - alpha * b[i];
}

void vec_copy(double *y, const double *x, int n) {
    memcpy(y, x, (size_t)n * sizeof(double));
}

void vec_zero(double *y, int n) {
    memset(y, 0, (size_t)n * sizeof(double));
}

double vec_norm2(const double *x, int n) {
    return sqrt(vec_dot(x, x, n));
}
