/**
 * csr_matrix.h - Compressed Sparse Row (CSR) matrix module
 *
 * Mixed precision: matrix values are stored in BOTH float32 and float64.
 *  - vals_f64: reference (high precision) copy
 *  - vals_f32: low precision copy used in mixed-precision SpMV
 *
 * Format (CSR):
 *   row_ptr[i]   : index in col_idx/vals where row i starts
 *   row_ptr[n]   : total number of non-zeros (nnz)
 *   col_idx[k]   : column index of the k-th non-zero
 *   vals_f64[k]  : value of the k-th non-zero (double)
 *   vals_f32[k]  : value of the k-th non-zero (float)
 */
#ifndef CSR_MATRIX_H
#define CSR_MATRIX_H

#include <stddef.h>

typedef struct {
    int  nrows;        /* number of rows (local rows for MPI) */
    int  ncols;        /* number of columns (= global N for distributed case) */
    int  nnz;          /* number of non-zero entries */
    int *row_ptr;      /* size nrows+1 */
    int *col_idx;      /* size nnz, GLOBAL column indices */
    double *vals_f64;  /* size nnz, double-precision values */
    float  *vals_f32;  /* size nnz, single-precision values */
} CSRMatrix;

/* Allocate CSR storage. nnz can be 0 if filled later. */
void csr_alloc(CSRMatrix *A, int nrows, int ncols, int nnz);

/* Free all internal buffers. */
void csr_free(CSRMatrix *A);

/* Build float32 mirror from float64 values. Call after filling vals_f64. */
void csr_build_f32_copy(CSRMatrix *A);

/*
 * Generate a synthetic 2D 5-point Laplacian-like pentadiagonal matrix.
 * Used for testing without external matrix files.
 *
 *   - global_n   : global matrix dimension (n x n)
 *   - row_start  : index of first row owned by this process
 *   - local_n    : number of rows owned by this process
 *
 * Strictly diagonally dominant => well-conditioned, BiCGSTAB converges fast.
 */
void csr_generate_pentadiagonal(CSRMatrix *A,
                                int global_n,
                                int row_start,
                                int local_n);

/* ---------- SpMV kernels ---------- */

/* Reference (full double precision) SpMV: y = A * x_full */
void csr_spmv_f64(const CSRMatrix *A, const double *x_full, double *y);

/*
 * Mixed-precision SpMV: y = A * x_full
 * Reads matrix values from vals_f32 (half the bandwidth),
 * casts to double, multiplies with x_full (double), accumulates in double.
 */
void csr_spmv_mixed(const CSRMatrix *A, const double *x_full, double *y);

/* OpenMP-parallel mixed-precision SpMV */
void csr_spmv_mixed_omp(const CSRMatrix *A, const double *x_full, double *y);

#endif /* CSR_MATRIX_H */
