/**
 * timer.h - Simple wall-clock timer (POSIX clock_gettime).
 */
#ifndef TIMER_H
#define TIMER_H

/* Return current monotonic wall-clock time in seconds. */
double wtime(void);

#endif
