/**
 * csr_matrix.c - CSR matrix module implementation.
 */
#include "csr_matrix.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _OPENMP
#include <omp.h>
#endif

void csr_alloc(CSRMatrix *A, int nrows, int ncols, int nnz) {
    A->nrows = nrows;
    A->ncols = ncols;
    A->nnz   = nnz;
    A->row_ptr  = (int *)calloc((size_t)(nrows + 1), sizeof(int));
    A->col_idx  = (nnz > 0) ? (int *)malloc((size_t)nnz * sizeof(int))     : NULL;
    A->vals_f64 = (nnz > 0) ? (double *)malloc((size_t)nnz * sizeof(double)) : NULL;
    A->vals_f32 = (nnz > 0) ? (float  *)malloc((size_t)nnz * sizeof(float))  : NULL;
    if (!A->row_ptr || (nnz > 0 && (!A->col_idx || !A->vals_f64 || !A->vals_f32))) {
        fprintf(stderr, "csr_alloc: out of memory\n");
        exit(EXIT_FAILURE);
    }
}

void csr_free(CSRMatrix *A) {
    free(A->row_ptr);  A->row_ptr  = NULL;
    free(A->col_idx);  A->col_idx  = NULL;
    free(A->vals_f64); A->vals_f64 = NULL;
    free(A->vals_f32); A->vals_f32 = NULL;
    A->nrows = A->ncols = A->nnz = 0;
}

void csr_build_f32_copy(CSRMatrix *A) {
    /* fp64 -> fp32 cast: SpMV sirasinda matrisi yarim bant genisligi ile okumak icin. */
    for (int k = 0; k < A->nnz; k++) {
        A->vals_f32[k] = (float)A->vals_f64[k];
    }
}

/*
 * Pentadiagonal matrix:
 *   diag = 6, off-diagonals (-2,-1,+1,+2) = -1
 * This is strictly diagonally dominant (|6| > 4) so BiCGSTAB converges quickly.
 */
void csr_generate_pentadiagonal(CSRMatrix *A,
                                int global_n,
                                int row_start,
                                int local_n) {
    /* Upper bound on nnz: 5 per row */
    int max_nnz = local_n * 5;

    csr_alloc(A, local_n, global_n, max_nnz);

    int nnz = 0;
    const int offsets[5] = {-2, -1, 0, 1, 2};
    for (int i = 0; i < local_n; i++) {
        A->row_ptr[i] = nnz;
        int gi = row_start + i;
        for (int k = 0; k < 5; k++) {
            int gj = gi + offsets[k];
            if (gj < 0 || gj >= global_n) continue;
            A->col_idx[nnz]  = gj;
            A->vals_f64[nnz] = (offsets[k] == 0) ? 6.0 : -1.0;
            nnz++;
        }
    }
    A->row_ptr[local_n] = nnz;
    A->nnz = nnz;

    /* Shrink (optional): we keep over-allocated buffers, harmless. */

    /* Build float32 mirror */
    csr_build_f32_copy(A);
}

/* ---------- SpMV ---------- */

void csr_spmv_f64(const CSRMatrix *A, const double *x_full, double *y) {
    for (int i = 0; i < A->nrows; i++) {
        double sum = 0.0;
        int row_end = A->row_ptr[i + 1];
        for (int k = A->row_ptr[i]; k < row_end; k++) {
            sum += A->vals_f64[k] * x_full[A->col_idx[k]];
        }
        y[i] = sum;
    }
}

void csr_spmv_mixed(const CSRMatrix *A, const double *x_full, double *y) {
    /* Mixed precision: matrisi fp32 oku, akumulasyonu fp64 yap. */
    for (int i = 0; i < A->nrows; i++) {
        double sum = 0.0;
        int row_end = A->row_ptr[i + 1];
        for (int k = A->row_ptr[i]; k < row_end; k++) {
            sum += (double)A->vals_f32[k] * x_full[A->col_idx[k]];
        }
        y[i] = sum;
    }
}

void csr_spmv_mixed_omp(const CSRMatrix *A, const double *x_full, double *y) {
    /* csr_spmv_mixed ile ayni; satirlar bagimsiz oldugu icin sadece dis dongu paralel. */
#ifdef _OPENMP
    #pragma omp parallel for schedule(static)
#endif
    for (int i = 0; i < A->nrows; i++) {
        double sum = 0.0;
        int row_end = A->row_ptr[i + 1];
        for (int k = A->row_ptr[i]; k < row_end; k++) {
            sum += (double)A->vals_f32[k] * x_full[A->col_idx[k]];
        }
        y[i] = sum;
    }
}
