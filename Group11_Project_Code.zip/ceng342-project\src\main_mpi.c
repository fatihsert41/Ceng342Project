/**
 * main_mpi.c - Driver for the MPI + OpenMP Mixed Precision BiCGSTAB.
 *
 * Usage:
 *   OMP_NUM_THREADS=4 mpirun -np 4 ./bicgstab_mpi [N] [max_iter] [tol]
 */
#include "bicgstab.h"
#include "csr_matrix.h"
#include "vector_ops.h"
#include "timer.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>

#ifdef _OPENMP
#include <omp.h>
#endif

/* Compute the row range owned by `rank` for a global problem of size N. */
static void partition_rows(int N, int rank, int nprocs,
                           int *row_start_out, int *local_n_out) {
    int base = N / nprocs;
    int rem  = N % nprocs;
    *local_n_out   = base + (rank < rem ? 1 : 0);
    *row_start_out = rank * base + (rank < rem ? rank : rem);
}

int main(int argc, char *argv[]) {
    int provided = 0;
    MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &provided);

    int rank, nprocs;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    int    N        = (argc > 1) ? atoi(argv[1]) : 10000;
    int    max_iter = (argc > 2) ? atoi(argv[2]) : 1000;
    double tol      = (argc > 3) ? atof(argv[3]) : 1e-8;

    int nthreads = 1;
#ifdef _OPENMP
    #pragma omp parallel
    {
        #pragma omp master
        nthreads = omp_get_num_threads();
    }
#endif

    if (rank == 0) {
        printf("=== Mixed Precision BiCGSTAB (MPI + OpenMP) ===\n");
        printf("  N=%d  max_iter=%d  tol=%e\n", N, max_iter, tol);
        printf("  MPI ranks   : %d\n", nprocs);
        printf("  OMP threads : %d  (per rank)\n", nthreads);
        printf("  Matrix values: fp32 (mixed precision SpMV)\n");
        printf("  Vectors      : fp64\n");
        printf("  Reductions   : MPI_Iallreduce (non-blocking)\n\n");
    }

    int row_start, local_n;
    partition_rows(N, rank, nprocs, &row_start, &local_n);

    CSRMatrix A;
    csr_generate_pentadiagonal(&A, N, row_start, local_n);

    /* Build local b from x_exact = ones.
     * We need a full x_exact vector for SpMV (since col_idx are global).
     */
    double *x_exact_full = (double *)malloc((size_t)N * sizeof(double));
    for (int i = 0; i < N; i++) x_exact_full[i] = 1.0;

    double *b_local = (double *)malloc((size_t)local_n * sizeof(double));
    csr_spmv_mixed_omp(&A, x_exact_full, b_local);

    double *x_local = (double *)calloc((size_t)local_n, sizeof(double));

    BiCGSTABParams params = { max_iter, tol, 1 };
    BiCGSTABResult res = bicgstab_mpi(&A, b_local, x_local,
                                      N, row_start, &params,
                                      MPI_COMM_WORLD);

    /* Compute global L2 error vs x_exact = ones */
    double err_loc = 0.0;
    for (int i = 0; i < local_n; i++) {
        double d = x_local[i] - 1.0;
        err_loc += d * d;
    }
    double err_glb = 0.0;
    MPI_Reduce(&err_loc, &err_glb, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("\n--- Results ---\n");
        printf("  iterations   : %d\n", res.iters);
        printf("  converged    : %s\n", res.converged ? "yes" : "no");
        printf("  final |r|/|b|: %e\n", res.final_resnorm);
        printf("  L2 error     : %e\n", sqrt(err_glb));
        printf("  time         : %.4f s\n", res.elapsed_sec);
        if (res.iters > 0)
            printf("  time/iter    : %.4f ms\n",
                   1000.0 * res.elapsed_sec / res.iters);
    }

    free(x_exact_full); free(b_local); free(x_local);
    csr_free(&A);

    MPI_Finalize();
    return res.converged ? 0 : 1;
}
