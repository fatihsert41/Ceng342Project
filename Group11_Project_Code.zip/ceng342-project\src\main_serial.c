/**
 * main_serial.c - Driver for the serial Mixed Precision BiCGSTAB.
 *
 * Usage: ./bicgstab_serial [N] [max_iter] [tol]
 */
#include "bicgstab.h"
#include "csr_matrix.h"
#include "vector_ops.h"
#include "timer.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    int    N        = (argc > 1) ? atoi(argv[1]) : 10000;
    int    max_iter = (argc > 2) ? atoi(argv[2]) : 1000;
    double tol      = (argc > 3) ? atof(argv[3]) : 1e-8;

    printf("=== Mixed Precision BiCGSTAB (Serial) ===\n");
    printf("  N=%d  max_iter=%d  tol=%e\n", N, max_iter, tol);
    printf("  Matrix values:  fp32  (mixed precision SpMV)\n");
    printf("  Vectors:        fp64\n\n");

    /* Build matrix (single rank => row_start=0, local_n=N) */
    CSRMatrix A;
    csr_generate_pentadiagonal(&A, N, 0, N);

    /* Exact solution = ones; b = A * x_exact (in mixed precision) */
    double *x_exact = (double *)malloc((size_t)N * sizeof(double));
    double *b       = (double *)malloc((size_t)N * sizeof(double));
    double *x       = (double *)calloc((size_t)N, sizeof(double));
    for (int i = 0; i < N; i++) x_exact[i] = 1.0;
    csr_spmv_mixed(&A, x_exact, b);

    BiCGSTABParams params = { max_iter, tol, 1 };
    BiCGSTABResult res = bicgstab_serial(&A, b, x, &params);

    /* L2 error */
    double err = 0.0;
    for (int i = 0; i < N; i++) {
        double d = x[i] - 1.0;
        err += d * d;
    }
    err = sqrt(err);

    printf("\n--- Results ---\n");
    printf("  iterations   : %d\n", res.iters);
    printf("  converged    : %s\n", res.converged ? "yes" : "no");
    printf("  final |r|/|b|: %e\n", res.final_resnorm);
    printf("  L2 error     : %e\n", err);
    printf("  time         : %.4f s\n", res.elapsed_sec);
    if (res.iters > 0)
        printf("  time/iter    : %.4f ms\n", 1000.0 * res.elapsed_sec / res.iters);

    free(x_exact); free(b); free(x);
    csr_free(&A);
    return res.converged ? 0 : 1;
}
