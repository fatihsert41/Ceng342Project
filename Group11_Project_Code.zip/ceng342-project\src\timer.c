#include "timer.h"

#if defined(_WIN32)
/* Windows: QueryPerformanceCounter (yuksek cozunurluklu monotonic saat). */
#include <windows.h>

double wtime(void) {
    LARGE_INTEGER freq, t;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t);
    return (double)t.QuadPart / (double)freq.QuadPart;
}

#else
/* POSIX (Linux/Mac): clock_gettime(CLOCK_MONOTONIC). */
#include <time.h>

double wtime(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

#endif
