/**
 * bicgstab_omp.c - OpenMP-parallel Mixed Precision BiCGSTAB.
 *
 * Same algorithm as the serial version, but every BLAS-1 / SpMV kernel
 * is replaced by its OpenMP variant. Reductions inside dot products use
 * `#pragma omp parallel for reduction(+:...)`.
 */
#include "bicgstab.h"
#include "vector_ops.h"
#include "csr_matrix.h"
#include "timer.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef _OPENMP
#include <omp.h>
#endif

BiCGSTABResult bicgstab_omp(const CSRMatrix *A,
                            const double *b,
                            double *x,
                            const BiCGSTABParams *params) {
    int n = A->nrows;
    BiCGSTABResult res = {0, 0.0, 0, 0.0};

    double *r     = (double *)malloc((size_t)n * sizeof(double));
    double *r_hat = (double *)malloc((size_t)n * sizeof(double));
    double *p     = (double *)malloc((size_t)n * sizeof(double));
    double *v     = (double *)malloc((size_t)n * sizeof(double));
    double *s     = (double *)malloc((size_t)n * sizeof(double));
    double *t     = (double *)malloc((size_t)n * sizeof(double));

    double t_start = wtime();

    /* r0 = b - A*x0 */
    csr_spmv_mixed_omp(A, x, v);
    vec_sub_scaled_omp(r, b, 1.0, v, n);

#ifdef _OPENMP
    #pragma omp parallel for schedule(static)
#endif
    for (int i = 0; i < n; i++) {
        r_hat[i] = r[i];
        p[i]     = r[i];
    }

    double bnorm = vec_norm2_omp(b, n);
    if (bnorm == 0.0) bnorm = 1.0;

    double rho_old = vec_dot_omp(r_hat, r, n);
    double alpha = 1.0, omega = 1.0, beta = 0.0;
    double rnorm = vec_norm2_omp(r, n);

    int k;
    for (k = 0; k < params->max_iter; k++) {
        if (rnorm / bnorm < params->tol) {
            res.converged = 1;
            break;
        }

        csr_spmv_mixed_omp(A, p, v);

        double rhv = vec_dot_omp(r_hat, v, n);
        if (rhv == 0.0) { fprintf(stderr, "  [omp] breakdown <r_hat,v>=0\n"); break; }
        alpha = rho_old / rhv;

        vec_sub_scaled_omp(s, r, alpha, v, n);

        double snorm = vec_norm2_omp(s, n);
        if (snorm / bnorm < params->tol) {
            vec_axpy_omp(x, alpha, p, n);
            rnorm = snorm;
            res.converged = 1;
            k++;
            break;
        }

        csr_spmv_mixed_omp(A, s, t);

        double ts = vec_dot_omp(t, s, n);
        double tt = vec_dot_omp(t, t, n);
        if (tt == 0.0) { fprintf(stderr, "  [omp] breakdown <t,t>=0\n"); break; }
        omega = ts / tt;

        vec_axpy_omp(x, alpha, p, n);
        vec_axpy_omp(x, omega, s, n);

        vec_sub_scaled_omp(r, s, omega, t, n);

        rnorm = vec_norm2_omp(r, n);
        if (params->verbose && (k % 50 == 0)) {
            printf("  [omp] iter %4d  |r|/|b| = %.3e\n", k, rnorm / bnorm);
        }

        double rho_new = vec_dot_omp(r_hat, r, n);
        if (omega == 0.0 || rho_old == 0.0) {
            fprintf(stderr, "  [omp] breakdown omega/rho=0\n");
            break;
        }
        beta = (rho_new / rho_old) * (alpha / omega);
        rho_old = rho_new;

        /* p = r + beta * (p - omega * v) (fused) */
#ifdef _OPENMP
        #pragma omp parallel for schedule(static)
#endif
        for (int i = 0; i < n; i++) {
            p[i] = r[i] + beta * (p[i] - omega * v[i]);
        }
    }

    res.iters         = k;
    res.final_resnorm = rnorm / bnorm;
    res.elapsed_sec   = wtime() - t_start;

    free(r); free(r_hat); free(p); free(v); free(s); free(t);
    return res;
}
