/**
 * main_omp.c - Driver for the OpenMP Mixed Precision BiCGSTAB.
 *
 * Usage: OMP_NUM_THREADS=8 ./bicgstab_omp [N] [max_iter] [tol]
 */
#include "bicgstab.h"
#include "csr_matrix.h"
#include "vector_ops.h"
#include "timer.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef _OPENMP
#include <omp.h>
#endif

int main(int argc, char *argv[]) {
    int    N        = (argc > 1) ? atoi(argv[1]) : 10000;
    int    max_iter = (argc > 2) ? atoi(argv[2]) : 1000;
    double tol      = (argc > 3) ? atof(argv[3]) : 1e-8;

    int nthreads = 1;
#ifdef _OPENMP
    #pragma omp parallel
    {
        #pragma omp master
        nthreads = omp_get_num_threads();
    }
#endif

    printf("=== Mixed Precision BiCGSTAB (OpenMP) ===\n");
    printf("  N=%d  max_iter=%d  tol=%e  threads=%d\n",
           N, max_iter, tol, nthreads);
    printf("  Matrix values:  fp32 (mixed precision SpMV, OpenMP)\n");
    printf("  Vectors:        fp64\n\n");

    CSRMatrix A;
    csr_generate_pentadiagonal(&A, N, 0, N);

    double *x_exact = (double *)malloc((size_t)N * sizeof(double));
    double *b       = (double *)malloc((size_t)N * sizeof(double));
    double *x       = (double *)calloc((size_t)N, sizeof(double));
    for (int i = 0; i < N; i++) x_exact[i] = 1.0;
    csr_spmv_mixed_omp(&A, x_exact, b);

    BiCGSTABParams params = { max_iter, tol, 1 };
    BiCGSTABResult res = bicgstab_omp(&A, b, x, &params);

    double err = 0.0;
    for (int i = 0; i < N; i++) {
        double d = x[i] - 1.0;
        err += d * d;
    }
    err = sqrt(err);

    printf("\n--- Results ---\n");
    printf("  iterations   : %d\n", res.iters);
    printf("  converged    : %s\n", res.converged ? "yes" : "no");
    printf("  final |r|/|b|: %e\n", res.final_resnorm);
    printf("  L2 error     : %e\n", err);
    printf("  time         : %.4f s\n", res.elapsed_sec);
    if (res.iters > 0)
        printf("  time/iter    : %.4f ms\n", 1000.0 * res.elapsed_sec / res.iters);

    free(x_exact); free(b); free(x);
    csr_free(&A);
    return res.converged ? 0 : 1;
}
