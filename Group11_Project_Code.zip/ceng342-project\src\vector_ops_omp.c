/**
 * vector_ops_omp.c - OpenMP-parallel BLAS-1 like vector kernels.
 *
 * Seri versiyonlardan tek farki: dis for dongulerine OpenMP pragma'lari
 * eklenmesi. Dot/norm fonksiyonlari `reduction(+:s)` kullanir cunku her
 * thread kendi kismi toplamini hesaplar ve sonunda hepsi birlestirilir.
 *
 * `schedule(static)` tercih edildi cunku tum elemanlar esit is yuku
 * tasiyor (basit BLAS-1 islemi); dinamik scheduling sadece overhead ekler.
 */
#include "vector_ops.h"
#include <math.h>

#ifdef _OPENMP
#include <omp.h>
#endif

double vec_dot_omp(const double *a, const double *b, int n) {
    double s = 0.0;
#ifdef _OPENMP
    #pragma omp parallel for reduction(+:s) schedule(static)
#endif
    for (int i = 0; i < n; i++) s += a[i] * b[i];
    return s;
}

void vec_axpy_omp(double *y, double alpha, const double *x, int n) {
#ifdef _OPENMP
    #pragma omp parallel for schedule(static)
#endif
    for (int i = 0; i < n; i++) y[i] += alpha * x[i];
}

void vec_axpby_omp(double *y, double alpha, const double *x,
                   double beta, int n) {
#ifdef _OPENMP
    #pragma omp parallel for schedule(static)
#endif
    for (int i = 0; i < n; i++) y[i] = beta * y[i] + alpha * x[i];
}

void vec_sub_scaled_omp(double *z, const double *a, double alpha,
                        const double *b, int n) {
#ifdef _OPENMP
    #pragma omp parallel for schedule(static)
#endif
    for (int i = 0; i < n; i++) z[i] = a[i] - alpha * b[i];
}

double vec_norm2_omp(const double *x, int n) {
    return sqrt(vec_dot_omp(x, x, n));
}
